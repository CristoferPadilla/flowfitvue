
<template>
    <div id="app">
        <historySell></historySell>
      </div>
  </template>
  
  <script>
    import historySell from '@/components/historySell.vue'
    
    export default {
    name: 'historyView',
    components: {
        historySell

    }
    }
  </script>