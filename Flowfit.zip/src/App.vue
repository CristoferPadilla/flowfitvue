<template>
    <router-view>
    </router-view>
  </template>
    
  <script>
  import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap';

  export default {
    name: 'StartApp',

  }
  </script>
