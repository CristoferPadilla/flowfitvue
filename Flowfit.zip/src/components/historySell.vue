<template>
<div>

</div>
    
</template>

<script>
export default {
    name: 'historyView',

}

</script>

<style scoped>


</style>